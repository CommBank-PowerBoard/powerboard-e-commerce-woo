<?php
declare( strict_types=1 );

namespace PowerBoard\Enums;

class SettingsSectionEnum {
	public const WIDGET_CONFIGURATION = POWER_BOARD_PLUGIN_PREFIX;
}
