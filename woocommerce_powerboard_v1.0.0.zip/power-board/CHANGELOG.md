# Changelog

## [1.0.0] - 2025-02-14

Initial Release

### Compatibility

- Compatible with WooCommerce version `9.5.2`.
